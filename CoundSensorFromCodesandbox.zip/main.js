main();

async function main() {
  const countElemnt = document.getElementById("count");
  const sensor0 = document.getElementById("sensor0");
  const sensor1 = document.getElementById("sensor1");
  const gpioAccess = await navigator.requestGPIOAccess();
  const dPort0 = gpioAccess.ports.get(12);
  const dPort1 = gpioAccess.ports.get(13);
  await dPort0.export("in");
  await dPort1.export("in");
  let lastOnTime0 = null;
  let lastOnTime1 = null;
  const maxDelay = 2000; // センサー0,1 検知時刻差の上限 (ms)
  let counter = 0;

  dPort0.onchange = function (v) {
    console.log(Date.now(), v);
    if (v === 1) {
      // センサー0 がオンに切り替わった (0側に人を検知)
      lastOnTime0 = Date.now(); // 時間の経過と共に大きくなる整数値
      // センサー0 がオンになった時刻 (現在) と直近のセンサー1 オン時の時刻差を確認
      if (lastOnTime0 - lastOnTime1 < maxDelay) {
        // maxDelay 以内に　１=>０　の順に検知している = 人が通った
        sensor0.innerHTML = "0: ON (1 -> 0)";
        counter++;
        post({ type: "update-room", id: 3608, value: 1 });
        countElemnt.innerHTML = counter;
      } else {
        // 時間内に 1 はオンに切り替わっていない
        sensor0.innerHTML = "0: ON";
      }
    } else {
      // センサー0 がオフに切り替わった (0側の人がいなくなった)
      // 実はこのオフになったタイミングでも時間差を確認するなどしても良いが
      // オフになるまでの時間はセンサー側の設定(目盛り)次第で差が激しいので
      // 人の移動の検知には使わない。検知しなくなったことを画面に出すだけに留める
      sensor0.innerHTML = "0: OFF";
    }
  };
  dPort1.onchange = function (v) {
    if (v === 1) {
      lastOnTime1 = Date.now();
      // センサー1 がオンになった時刻 (現在) と直近のセンサー0 オン時の時刻差を確認
      // ここが上のコピペで lastOnTime0 - lastOnTime1 (常に負になる=常に真となる) だったのがバグ
      // これでホントに時刻差が maxDelay 以内の時だけ counter-- されるように
      if (lastOnTime1 - lastOnTime0 < maxDelay) {
        // maxDelay 以内に　0=>1　の順に検知している = 人が通った
        sensor1.innerHTML = "1: ON (0 -> 1)";
        counter--;
        post({ type: "update-room", id: 3608, value: -1 });
        countElemnt.innerHTML = counter;
      } else {
        sensor1.innerHTML = "1: ON";
      }
    } else {
      sensor1.innerHTML = "1: OFF";
    }
  };
}

async function post(data) {
  const url = "https://anti-crowded.com/api";
  const options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  };
  const res = await fetch(url, options);
  console.log(await res.text());
}
